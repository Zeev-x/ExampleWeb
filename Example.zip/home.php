<div class="page">
  <h3>Membuat Website Tanpa Coding</h3>
  <form action="maker.php" method="post">
    <table>
      <tr>
        <td align="top" width="100">Nama Web</td>
        <td><textarea name="name" required></textarea></td>
      </tr>
      <tr>
        <td align="top" width="100">Judul Web</td>
        <td><textarea name="title" required></textarea></td>
      </tr>
      <tr>
        <td width="150" valign="top">Isi Web</td>
        <td><textarea name="isi" cols="50" rows="15" required></textarea></td>
      </tr>
      <tr align="center">  
        <td width="100" height="100px"></td>  
        <td><input type="submit" value="Proses"></td>  
        </tr>
    </table>
  </form>
  <br><br><br>
  <center>
    <hr>
    <h3>Contoh penggunaan website</h3>
    <hr>
    <img src="contoh1.jpg" height="500px">
    <p>Contoh penggunaan seperti gambar di atas,dan hasilnya akan jadi seperti ini :</p>
    <img src="contoh2.jpg" height="400px">
  </center>
</div>