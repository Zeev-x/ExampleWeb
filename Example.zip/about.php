<div class="page">
  <center>
    <h3>Tentang Website Ini</h3>
    <h6>Website ini di buat hanya untuk main-main,hasil website maker tidak bisa di jadikan website resmi atau di hosting.jikalau ingin mendapatkan file mentahan website ini bisa di unduh gratis di <a href="https://www.github.com/zeev-x/web_php.git">Sini</a>.</h6>
    <h3>Tentang Penulis</h3>
    <h6>Lynch selaku sang penulis website ini adalah pemula,jadi jika ada salah kata dalam pengetikan lynch memohon maaf yang sebesar-besarnya.</h6>
    <hr>  
    <h4>Report Area</h4>
    <hr>
 <form action="lapor.php" method="post">  
 <table width="80%" border="0">  
 
 <tr>  
      <td width="150" valign="top">Kritik dan saran :<br></td>  
      <td><textarea name="isi" cols="18" rows="3" required></textarea></td>  
 </tr>  
 <tr>  
      <td width="150"></td>  
      <td><input type="submit" value="simpan"></td>  
 </tr>  
 <tr></tr>
 </table> 
 <hr>
 </form>  
  </center>
</div>